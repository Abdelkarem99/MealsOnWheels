
package mealsonwheels;

import java.util.ArrayList;


public class Restuarant {
    
    String Name; 
    String Website;

    ArrayList<Branch>branchList = new ArrayList<>();

    public Restuarant(String Name, String Website) {
        this.Name = Name;
        this.Website = Website;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getWebsite() {
        return Website;
    }

    public void setWebsite(String Website) {
        this.Website = Website;
    }

    public ArrayList<Branch> getBranchList() {
        return branchList;
    }

    public void setBranchList(ArrayList<Branch> branchList) {
        this.branchList = branchList;
    }
    
    
    
    
}
