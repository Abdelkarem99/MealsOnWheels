
package mealsonwheels;

import  java.util.Scanner;

public class MealsOnWheels {

    
    public static void main(String[] args) {
      
        
        
        Restuarant KFC = new Restuarant("KFC","Kfc.com");
        
        Branch Br = new Branch("Amman" , 10 ,5 , 2);
        
        FoodItem fI = new FoodItem("Pizza" , 10);
        
        Order Or = new Order("1859410" , 2);
        
        Administrator Ads = new Administrator("" ,"Amane" , 0 , "");
        
        Client Cl = new Client("" , "Amane" , 5 , "2");
        
        DeliveryPerson DP = new DeliveryPerson("Mahmood" , 5 , "6");
        
        
        
        
        
       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
