
package mealsonwheels;


public class Branch {
    
    
    String address;
    int opening,closing,PhoneNumber;

    public Branch(String address, int opening, int closing, int PhoneNumber) {
        this.address = address;
        this.opening = opening;
        this.closing = closing;
        this.PhoneNumber = PhoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getOpening() {
        return opening;
    }

    public void setOpening(int opening) {
        this.opening = opening;
    }

    public int getClosing() {
        return closing;
    }

    public void setClosing(int closing) {
        this.closing = closing;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }
    
    
    
    
}
