
package mealsonwheels;


public class User {
    
    
    String username;
    int PhoneNumber;
    String Password;

    public User(String username, int PhoneNumber, String Password) {
        this.username = username;
        this.PhoneNumber = PhoneNumber;
        this.Password = Password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    public void print(){
        
    }
    
    
    
    
    
}
