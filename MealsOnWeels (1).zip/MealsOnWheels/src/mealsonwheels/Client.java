
package mealsonwheels;


public class Client extends User{
    
    
    String Address;
    
    Boolean verified;

    public Client(String Address, Boolean verified, String username, int PhoneNumber, String Password) {
        super(username, PhoneNumber, Password);
        this.Address = Address;
        this.verified = verified;
    }

    Client(String string, String amane, int i, String string0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

  
    
    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public Boolean getVerified() {
        return verified;
    }

    public void setVerified(Boolean verified) {
        this.verified = verified;
    }
    
    
    public void print(){
        System.out.println("user name:"  +  username);
        
        
    }
    
    
}
