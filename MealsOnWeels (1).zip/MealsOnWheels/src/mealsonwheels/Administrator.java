
package mealsonwheels;


public class Administrator extends User {
    
    
    String Email;

    public Administrator(String Email, String username, int PhoneNumber, String Password) {
        super(username, PhoneNumber, Password);
        this.Email = Email;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    
    public void print(){
    
    
        System.out.println("User name:" + username); 
    }
    
}
