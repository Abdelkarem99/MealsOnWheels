
package mealsonwheels;

import java.util.ArrayList;


public class Order {
    
    
    String SerialNumber;
    int OrderTime;
    
    
     ArrayList<FoodItem>foodlist = new ArrayList<>();

    public Order(String SerialNumber, int OrderTime) {
        this.SerialNumber = SerialNumber;
        this.OrderTime = OrderTime;
    }

    public String getSerialNumber() {
        return SerialNumber;
    }

    public void setSerialNumber(String SerialNumber) {
        this.SerialNumber = SerialNumber;
    }

    public int getOrderTime() {
        return OrderTime;
    }

    public void setOrderTime(int OrderTime) {
        this.OrderTime = OrderTime;
    }

    public ArrayList<FoodItem> getFoodlist() {
        return foodlist;
    }

    public void setFoodlist(ArrayList<FoodItem> foodlist) {
        this.foodlist = foodlist;
    }
     
    
}
