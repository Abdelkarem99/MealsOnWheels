
package mealsonwheels;


public class DeliveryPerson extends User {
    
    Boolean available = true;

    public DeliveryPerson(String username, int PhoneNumber, String Password) {
        super(username, PhoneNumber, Password);
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(int PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    
    
    

public void Deliver(Order Or){

    available = false;
}
public void print(){
    
    System.out.println();
    
}
}
